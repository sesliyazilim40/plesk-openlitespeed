<?php

require_once pm_Context::getPlibDir() . '/library/Ols/L10n.php';

class Modules_Openlitespeed_Navigation extends pm_Hook_Navigation
{
    public function getNavigation()
    {
        return array(
            array(
                'controller' => 'index',
                'action' => 'index',
                'label' => 'OpenLiteSpeed',
                'pages' => array(
                    array(
                        'controller' => 'index',
                        'action' => 'webengine',
                        'label' => Ols_L10n::t('Web Engine'),
                    ),
                    array(
                        'controller' => 'index',
                        'action' => 'vhosts',
                        'label' => Ols_L10n::t('Virtual Hosts'),
                    ),
                    array(
                        'controller' => 'index',
                        'action' => 'logs',
                        'label' => Ols_L10n::t('Logs'),
                    ),
                    array(
                        'controller' => 'index',
                        'action' => 'config',
                        'label' => Ols_L10n::t('Configuration'),
                    ),
                    array(
                        'controller' => 'index',
                        'action' => 'settings',
                        'label' => Ols_L10n::t('Settings'),
                    ),
                ),
            ),
        );
    }
}
