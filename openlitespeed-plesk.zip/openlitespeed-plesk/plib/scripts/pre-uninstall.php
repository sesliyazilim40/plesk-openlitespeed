<?php
pm_Context::init('openlitespeed');

$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    @mkdir($varDir, 0750, true);
}

$log = $varDir . '/uninstall.log';
$write = function ($line) use ($log) {
    @file_put_contents($log, date('Y-m-d H:i:s') . ' ' . $line . "\n", FILE_APPEND);
};

/*
 * Upgrading from inside the OpenLiteSpeed page runs this script too, and an
 * upgrade must change nothing: the front stays owned by OpenLiteSpeed and the
 * automatic sync keeps running. The helper leaves that marker behind while it
 * installs a package, in this module's own directory and in a copy outside it -
 * Plesk deletes the module directory while it replaces the package, and the copy
 * is what lets a later install still see that nothing was being removed. The
 * marker is only trusted for as long as an install can reasonably take, so an old
 * one can never silence the removal guard.
 */
$upgradeAge = null;
foreach (array(
    '/var/lib/plesk-openlitespeed-front/upgrading.json',
    '/usr/local/psa/var/modules/openlitespeed/engine/upgrading.json',
    '/opt/psa/var/modules/openlitespeed/engine/upgrading.json',
) as $marker) {
    if (!is_file($marker)) {
        continue;
    }
    $data = json_decode((string) @file_get_contents($marker), true);
    $upgradeAge = is_array($data) && isset($data['started'])
        ? time() - (int) strtotime((string) $data['started'])
        : null;
    break;
}

if ($upgradeAge !== null && $upgradeAge >= 0 && $upgradeAge <= 1800) {
    $write('upgrade in progress (' . $upgradeAge . 's): nothing was touched');

    return;
}

$helper = null;
foreach (array(
    '/usr/local/psa/admin/sbin/modules/openlitespeed/openlitespeed',
    '/opt/psa/admin/sbin/modules/openlitespeed/openlitespeed',
) as $candidate) {
    if (is_executable($candidate)) {
        $helper = $candidate;
        break;
    }
}

/**
 * Removal guard, before anything gets deleted: while OpenLiteSpeed is the front
 * that answers public HTTP and HTTPS for Plesk's domains, taking this extension
 * away would leave those domains mapped by a configuration nobody maintains any
 * more. The administrator switches the front back first; only then is removal
 * allowed. Anything the guard cannot confirm is treated as "not our front", so
 * a broken OpenLiteSpeed can never lock the administrator out of the removal.
 */
if ($helper !== null) {
    $output = array();
    $code = 0;
    @exec($helper . ' --action=front-active 2>&1', $output, $code);
    $text = trim(implode("\n", $output));
    $front = json_decode($text, true);
    $write('front-active exit=' . $code . ' response=' . $text);

    if (is_array($front) && !empty($front['is_front'])) {
        $write('removal refused: OpenLiteSpeed is still the web front');

        fwrite(STDERR, implode("\n", array(
            'OpenLiteSpeed is still the web front of this server, so this extension was NOT removed.',
            '',
            'Ports 80/443 are currently served by OpenLiteSpeed for every Plesk domain. Removing the',
            'extension now would leave those domains behind a front-end configuration with no owner.',
            '',
            'Switch the web front back to Plesk first, then remove the extension again:',
            '  Plesk -> OpenLiteSpeed -> Web engine -> "Switch to Plesk (nginx + Apache)"',
            '  or, as root:  ' . $helper . ' --action=engine-revert',
            '',
            'Nothing on this server was changed by this removal attempt.',
            '',
            '---------------------------------------------------------------------------',
            '',
            'OpenLiteSpeed bu sunucunun web ön katmanı olduğu için bu eklenti KALDIRILMADI.',
            '',
            '80/443 portlarını şu anda tüm Plesk alan adları için OpenLiteSpeed sunuyor; eklentiyi',
            'şimdi kaldırmak, bu alan adlarını sahibi kalmamış bir ön katman yapısında bırakırdı.',
            '',
            "Önce Plesk'in web ön katmanına dönün, sonra eklentiyi kaldırın:",
            '  Plesk -> OpenLiteSpeed -> Web motoru -> "Plesk\'e Dön (nginx + Apache)"',
            '  veya root olarak:  ' . $helper . ' --action=engine-revert',
            '',
            'Bu kaldırma denemesinde sunucuda hiçbir şey değiştirilmedi.',
            '',
        )) . "\n");

        exit(1);
    }
}

// The automatic front sync timer belongs to the extension: never leave it behind.
$cron = '/etc/cron.d/plesk-openlitespeed-front';
if (is_file($cron)) {
    @unlink($cron);
    $write('removed cron file ' . $cron);
}

$flash = $varDir . '/flash.json';
if (is_file($flash)) {
    @unlink($flash);
}

// The first-run wizard remembers that the administrator has been through it.
// Dropping that record is what makes a later reinstall ask the question again.
foreach (array('/engine/setup.json', '/engine/setup.log') as $relative) {
    if (is_file($varDir . $relative)) {
        @unlink($varDir . $relative);
        $write('removed setup state ' . $relative);
    }
}

/*
 * The guard above already refused the dangerous case, so what is left here is
 * the tidy-up: any half-finished front ownership is put back on Plesk's stock
 * nginx + Apache. engine-revert never aborts, problems come back as warnings.
 */
if ($helper === null) {
    $write('helper binary not found; the web front was left untouched');

    return;
}

$output = array();
$code = 0;
@exec($helper . ' --action=engine-revert 2>&1', $output, $code);
$text = trim(implode("\n", $output));
$data = json_decode($text, true);

$write('engine-revert exit=' . $code . ' response=' . $text);

if (!is_array($data) || empty($data['ok'])) {
    echo "OpenLiteSpeed: could not switch the web front back to nginx + Apache."
        . " Check /usr/local/lsws/conf/httpd_config.conf and run 'systemctl enable --now nginx'"
        . " before removing this extension. Details: " . $text . "\n";

    return;
}

if (!empty($data['reverted'])) {
    echo "OpenLiteSpeed: the web front was switched back to nginx + Apache and the automatic sync was removed.\n";
} else {
    echo "OpenLiteSpeed: nginx was already the web front; nothing had to be reverted.\n";
}

foreach ((array) (isset($data['warnings']) ? $data['warnings'] : array()) as $warning) {
    echo 'OpenLiteSpeed: ' . $warning . "\n";
}
