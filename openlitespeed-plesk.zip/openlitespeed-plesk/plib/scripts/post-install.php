<?php
pm_Context::init('openlitespeed');

$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    mkdir($varDir, 0750, true);
}

$moduleId = pm_Context::getModuleId();
$helpers = array(
    '/usr/local/psa/admin/bin/modules/' . $moduleId . '/openlitespeed',
    '/usr/local/psa/admin/sbin/modules/' . $moduleId . '/openlitespeed',
    '/usr/local/psa/admin/bin/modules/' . $moduleId . '/openlitespeed.php',
    '/usr/local/psa/admin/sbin/modules/' . $moduleId . '/openlitespeed.php',
);

foreach ($helpers as $helper) {
    if (file_exists($helper)) {
        chmod($helper, 0755);
    }
}

/*
 * The PHP pool for Plesk's own service hostnames moved out of the engine state
 * directory, because the OpenLiteSpeed worker has to reach its socket. Whatever
 * an older version left there belongs to nothing any more.
 */
foreach ((array) glob($varDir . '/engine/svc-fpm-*') as $stale) {
    if (is_file($stale)) {
        @unlink($stale);
    }
}

/*
 * Installing the extension is a fresh start for the welcome page: the record that
 * the administrator has been through it lives in this var directory, which
 * survives an upgrade in place. Without this the panel would go straight to the
 * dashboard after an install and never offer the one-click setup. An upgrade from
 * inside the OpenLiteSpeed page is marked by the helper and keeps that record, so
 * updating never throws the welcome page at somebody who already set the server up.
 */
$upgrading = false;
foreach (array(
    '/var/lib/plesk-openlitespeed-front/upgrading.json',
    '/usr/local/psa/var/modules/openlitespeed/engine/upgrading.json',
    '/opt/psa/var/modules/openlitespeed/engine/upgrading.json',
) as $marker) {
    if (!is_file($marker)) {
        continue;
    }
    $data = json_decode((string) @file_get_contents($marker), true);
    @unlink($marker);
    $age = is_array($data) && isset($data['started']) ? time() - (int) strtotime((string) $data['started']) : null;
    $upgrading = $age !== null && $age >= 0 && $age <= 1800;
    break;
}

if (!$upgrading) {
    /*
     * A command line install, and a re-install over an existing one, carry no upgrade
     * marker, yet Plesk has already deleted this module's var directory together with
     * the front state stored in it. The mirror kept outside the module's own
     * directories still says which front the administrator chose, and a server whose
     * front is OpenLiteSpeed is a server that has been set up: the welcome page must
     * not be thrown at it, and its timer belongs back in /etc/cron.d.
     */
    $mirror = json_decode(
        (string) @file_get_contents('/var/lib/plesk-openlitespeed-front/state.json'),
        true
    );
    $upgrading = is_array($mirror) && isset($mirror['mode']) && $mirror['mode'] === 'ols-front';
}

if (!$upgrading) {
    foreach (array('/engine/setup.json', '/engine/setup.log', '/engine/setup.pid', '/flash.json') as $relative) {
        if (is_file($varDir . $relative)) {
            @unlink($varDir . $relative);
        }
    }
}

/*
 * Put back the two things an install must never lose - the automatic sync timer and
 * the service that brings the chosen front up after a reboot. The helper only acts
 * while its state says OpenLiteSpeed is the front, restarts nothing and rewrites no
 * configuration, so this can never change which server answers 80/443.
 */
$helper = '/usr/local/psa/admin/sbin/modules/' . $moduleId . '/openlitespeed';
if (is_executable($helper)) {
    @exec($helper . ' --action=install-heal 2>&1', $output);
}
