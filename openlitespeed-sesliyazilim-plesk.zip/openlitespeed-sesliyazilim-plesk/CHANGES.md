# Changelog

## 1.4.5

Fixed the site that answered for a few minutes after a switch to OpenLiteSpeed and then
only with 503, measured on the production box it happened on.

- Fixed: a busy subscription dropped to 503 behind the direct front. OpenLiteSpeed hands a
  request to the PHP pool of that domain and waits just under a minute for the answer;
  Plesk starts every subscription with ten children and never looks at the machine, so
  from the eleventh simultaneous visitor on the requests queue and the front answers them
  as `ExtConn timed out while processing` and `oops! 503 Service Unavailable`. Measured
  there: 20 simultaneous requests gave 15 redirects and 5 of those 503, with 526 of the
  two lines above in two minutes, on a server with six CPUs and 5.6 GB free. The front now
  raises the child limit of every pool it serves requests from itself to four per CPU
  (eight at the least, forty at the most), and leaves Plesk's number alone on a server that
  has less than a gigabyte free to run them in. That box answered 20 of 20 and 40 of 40
  after it: `www.forumsal.net` 200, 374 889 bytes, 0.77 s.
- The limit stays raised: it lives in a file Plesk owns and rewrites whenever that domain's
  PHP settings are saved, so the two-minute tick applies it again - without writing or
  reloading anything on a server that already has enough room, and without ever lowering a
  limit that is higher. A pool whose php-fpm master cannot be reached is left exactly as it
  was found, since an unnoticed limit is no limit at all. "Switch to Plesk" puts back the
  number it had written, and only there: a raise made in Plesk since the switch stands.

## 1.4.4

Three fixes measured on a production box that went live with 1.4.3: a subscription
answered Plesk's default page instead of its own site, and one click on the Web engine
page had switched OpenLiteSpeed itself off, including its boot entry.

- Fixed: a domain Plesk serves on the address the whole server shares was invisible to
  the front, and such a server answered Plesk's default page for it. Plesk writes that
  VirtualHost under `plesk.conf.d/ip_default/<domain>.conf` and leaves
  `/var/www/vhosts/system/<domain>/conf/httpd.conf` as a comment-only stub, while the
  discovery only read the stub. Both layouts are now enumerated, and the file that
  really carries a `<VirtualHost>` block decides - the stub can no longer mask a
  subscription. Hostnames are also read when they are written without quotes, and a
  commented-out `ServerName` can no longer add one.
- Fixed: on a server where an installer linked `httpd.service` to OpenLiteSpeed's own
  unit - what the LiteSpeed one-click installer does so that Plesk restarts
  OpenLiteSpeed whenever it restarts Apache - releasing Apache stopped and disabled
  OpenLiteSpeed instead. A service name is now checked against the unit it really
  resolves to before the front touches it, both when the name is probed and when an
  older switch recorded it in the front state, so a recorded `httpd` that is
  OpenLiteSpeed is dropped rather than stopped. This is what made the box above lose
  both its sites and its boot entry in one click. The same name is what the two-minute
  tick watches for an Apache that came back: read unguarded, every tick believed
  OpenLiteSpeed itself was that Apache and skipped its own work as a repair still in
  cooldown, so a configuration the extension had already rebuilt never reached the
  server - measured as `{"changed":false,"skipped":"repair-cooldown"}` on three
  consecutive ticks.
- Fixed: the boot entry could be gone while the page still promised it. Whether the
  front starts after a reboot is now asked of systemd (`is-enabled`) instead of trusting
  the recorded flag, on the Web engine page and in the install heal, so a unit something
  outside this extension disabled is registered again - and a unit recorded under a
  second name is enabled under the name that owns the file.

## 1.4.3

- Added: the web front now survives a reboot. OpenLiteSpeed is registered for boot when
  it is switched on - using the service the OpenLiteSpeed packages already provide when
  there is one, and a unit this extension writes when there is none, because the EL8 RPM
  ships only `/etc/init.d/lsws` and `lswsctrl` and leaves nothing for systemd. A
  `@reboot` entry in the same timer file runs a reboot guard: it waits up to two minutes
  for OpenLiteSpeed to be seen holding ports 80/443, frees the ports from whatever
  answered there during boot, restarts OpenLiteSpeed once, and if it still cannot hold
  them, hands the public front back to Plesk and writes down why. So the server either
  comes back on OpenLiteSpeed or comes back on Plesk - it never comes back unserved.
  "Switch to Plesk" removes the unit it wrote and restores the enable state of a unit it
  only reused, which is what makes that switch return a stock server.
- Fixed: the panel could claim OpenLiteSpeed was the web front while Apache actually
  answered 80/443. The front verdict now also asks the kernel (`ss -lntp`) who owns
  those sockets, and both the header badge and the Web engine page say so - including
  the state a re-install can leave behind, where the front block is still in
  `httpd_config.conf` but the extension has lost its own state file. `front-active`,
  which is what the removal guard asks before refusing, uses the same answer, so a
  removal can no longer be blocked by a front that is not really serving.
- Fixed: installing a package could destroy the record of which front this server runs.
  Plesk deletes the module's own var directory during an install, and with it the state
  file, the backups and the sync timer, while the front block stayed live in the
  configuration - measured on a test server at 17:20:52. The front state is now mirrored
  under `/var/lib/plesk-openlitespeed-front/`, which Plesk does not touch, is adopted
  again when the state file is missing, and post-install runs a heal step that puts back
  the timer and the boot service without ever changing which server answers 80/443.
- Added: the two-minute timer now also covers the case neither service report shows -
  OpenLiteSpeed running but sitting on ports it never bound - and stops fighting after
  three failed repairs by handing the front back to Plesk, the same way the reboot guard
  does. The Web engine page shows who answers 80/443, what happens after a reboot, and
  an explicit message when OpenLiteSpeed holds the domain configuration but is not
  serving.

- Fixed: switching to the direct front could leave every PHP page answering
  "503 Service Unavailable / The server is temporarily busy, try again later!".
  The pool address was written as `uds://var/www/vhosts/system/<domain>/php-fpm.sock`:
  what follows `uds://` is the path verbatim, so dropping the socket's leading slash
  made OpenLiteSpeed look for the pool beside its own server root, and it then
  reported "Connection refused" for every request. The front keeps the absolute path
  now (`uds:///var/...`). `UDS:/var/...`, the other syntax in circulation, is
  rejected by this build outright ("failed to set socket address"), and neither
  mistake appears in `lshttpd -t`, which only checks the address can be parsed - the
  first real request is what shows it.
- Fixed: a front that answered plain HTTP but failed over HTTPS stayed switched. A
  domain Plesk configures as HTTPS-only answers the HTTP probe with its own 301 and
  never reaches PHP, so the health check could pass over a dead pool. HTTPS is now
  baselined before the cut-over and compared after it, and a newly failing domain on
  either side rolls the switch back on its own.
- Fixed: on a server whose Plesk webmail hostname carries an `Alias "/roundcube/"`
  line, the switch to the direct front refused to run at all: `The generated front
  configuration failed the 'lshttpd -t' check. Nothing was switched. … <type> is
  invalid: alias`. The alias context was written as `type alias`, a value LiteSpeed
  stopped accepting: `type` names a *handler* there (static, ssi, cgi, fcgi, proxy,
  lsapi, …) and a missing `type` already means the static handler. The alias now says
  only what it maps - `location <directory>` - the same form the document-root context
  of every generated vhost has always used.
- Fixed: the boot service was not registered on servers where the OpenLiteSpeed package
  installs a second name for its own unit. The EL10 package ships `lsws` as an alias of
  `lshttpd`, and `systemctl enable` refuses an alias, so the switch reported "could not
  be enabled for boot" while the front was otherwise live. Unit discovery now passes
  over an alias and registers the unit that owns the file.

## 1.4.2

- Fixed: Apache could take ports 80/443 back from OpenLiteSpeed about half a minute
  after a successful switch, and the customer sites silently went back to the old
  front. Measured on a test server: `Failed to start The Apache HTTP Server` at
  16:54:29, then `Service RestartSec=5s expired, scheduling restart` three times,
  then `Started The Apache HTTP Server` with `listening on: port 443, port 80` at
  16:54:45. Many Plesk servers carry a `Restart=on-failure` drop-in for Apache (that
  box had `/usr/lib/systemd/system/httpd.service.d/respawn.conf`, owned by no
  package), so *any* start attempt - logrotate's weekly `httpdmng --reload`, a domain
  edited in the panel, a renewed certificate - is retried every five seconds when it
  cannot bind, and it wins the moment OpenLiteSpeed releases the ports for its own
  restart. Three changes: a direct-mode switch now always runs `stop` and `disable`
  on Apache before it restarts OpenLiteSpeed, instead of only when Apache happened to
  be up, because `stop` is also what cancels the queued restart job; the two-minute
  timer re-asserts the front when it finds Apache running in direct mode even though
  nothing else changed, at most once every fifteen minutes so a server that insists
  on starting Apache is not restarted every tick; and the disabling that used to
  happen after the restart now happens before it.
- Fixed: two front operations could run at the same time - the timer's sync beside a
  panel click, or a second click while the first one was still restarting - and the
  second one's restart window collided with the first one's, which is what let
  Apache in above. Switch, cutover, sync and the timer now share one lock, so the
  second request answers "Another OpenLiteSpeed front operation is still running"
  instead of writing over it. A revert waits up to two minutes for the running
  operation rather than refusing, because removing the extension must never block.
- Fixed: the package install on AlmaLinux/RHEL 9 and 10 still stopped with
  "nothing provides libgd.so.103()(64bit) needed by lsphp83-gd" even with EPEL
  enabled. That libgd is not in Extra Packages at all - the distribution and EPEL
  only carry the older gd - and it is why the official LiteSpeed repository
  bootstrap also adds Remi from release 9 up. The setup now installs
  `remi-release` when it is missing, exactly like the bootstrap. Remi ships the
  newer library as its own package (`gd3php`), so the system's `gd`, `graphviz`
  and the existing PHP gd extension are left untouched: the install transaction
  only adds packages, it removes and upgrades nothing.
- The unresolvable-dependency message now names the Remi repository among the
  channels the setup has already enabled.
- Fixed: the setup stopped at "Building the front configuration and switching
  80/443" and never reported back when OpenLiteSpeed was controlled through
  `lswsctrl`. That script leaves the `lshttpd` daemon running in the background,
  and the daemon keeps the output pipe the helper was reading, so the helper
  waited for a pipe end that only closes when the web server stops. The service
  already had the ports and the sites were served; only the report was missing, so
  the page stayed on "running" and the automatic health check never armed. Commands
  that can leave a daemon behind now write their output to a file instead of a pipe.
- Fixed: a `.htaccess` in a subdirectory was ignored on a domain served directly
  by OpenLiteSpeed, so only the file in the document root was read. The virtual
  host config now carries `rewrite { enable 1 autoLoadHtaccess 1 }` beside the
  document root context: rewriting is on for the whole host and every directory
  loads its own `.htaccess` the first time it is reached, which is what a
  WordPress install or a site migrated from cPanel expects. Measured on the test
  server: with the block missing a `RewriteRule .* - [F,L]` in a subdirectory
  still answered 200, with it the same request answered 403, and editing that
  file afterwards took effect without another restart.
- Fixed: on a server whose web front is Apache alone, with no nginx installed,
  switching to OpenLiteSpeed produced no virtual hosts at all: the domains, their
  certificates and their document roots were only ever read from
  `/etc/nginx/plesk.conf.d/vhosts`, so the switch found an empty site list and
  then refused to touch anything. Plesk keeps the same facts in the configuration
  it maintains for Apache (`/var/www/vhosts/system/<domain>/conf/httpd.conf` and
  its own `plesk.conf.d`), and that is now the second source, for the domains,
  their names, certificates, HTTPS redirects, the public IPs and the server
  hostname's panel mapping. Webmail hostnames are read from the Apache directory
  too when the nginx one is empty.
- Because a server without nginx has no Apache waiting on a loopback port behind
  the front, the switch there serves every site directly instead of proxying, and
  it says so when a domain still cannot be served that way: Plesk must have a
  PHP-FPM pool for it. A domain whose PHP Apache itself runs (CGI or fcgid) is now
  given a pool of its own, started with the very PHP binary and `php.ini` Plesk
  configured for that domain, the same way the webmail hostnames already are.
  Switching back to Plesk on such a server hands ports 80/443 back to Apache.
- Fixed: on a server where nginx is only a leftover package - its service unit and
  binary are there, Plesk has no nginx configuration for its domains and Apache
  answers on ports 80/443 - the switch still chose the proxy front, left Apache
  running on the public ports and OpenLiteSpeed then exited with
  "Can't listen at address ...: Address already in use". Whether Apache can be
  proxied to is now decided by asking Apache itself on the loopback port Plesk
  names, not by trusting that a nginx service exists. The same check decides what
  "Switch to Plesk" and the removal guard bring back, so a leftover nginx is never
  started in Apache's place and never takes the public ports. When OpenLiteSpeed
  still fails to start, the failure now quotes the newest `[ERROR]` lines from its
  own log instead of only the exit text.
- The web admin console (the port this extension reports for "Web Admin Console")
  answered with OpenLiteSpeed's own self-signed certificate for the host
  `openlitespeed.host`, so every visit started with a browser warning. Its
  listener now uses the certificate Plesk already serves the panel with, the valid
  one for the server hostname, and since that is the same file Plesk writes on
  every renewal the console follows the renewal by itself. LiteSpeed's own
  certificate paths are remembered and put back when you switch to Plesk or remove
  the extension. A server without that panel certificate keeps LiteSpeed's files.

## 1.4.1

- Fixed: the package install on AlmaLinux/RHEL 8, 9 and 10 stopped with
  "nothing provides libgd.so.103()(64bit) needed by lsphp83-gd". The OpenLiteSpeed
  package pulls LiteSpeed's own PHP build as a dependency, and that build's gd
  module needs `gd`, which the distribution base repositories do not carry. The
  official LiteSpeed repository bootstrap adds Extra Packages for Enterprise
  Linux for exactly this reason, so the setup now installs `epel-release` when it
  is missing, before it looks the package up. The extension never runs that PHP:
  Plesk's own pools serve the sites.
- The setup log announces the metadata refresh and the install when they *start*,
  not only when the package manager has finished, so the journal no longer looks
  frozen while dnf downloads a repository index.
- The repository and signing-key URLs are the https form of what the official
  bootstrap writes. Some networks never complete the plain http hop to the
  repository host, which made the metadata lookup fail with "Unable to connect to
  …" and looked like an unsupported distribution. An existing
  `/etc/yum.repos.d/openlitespeed-stable.repo` written by 1.4.0 is rewritten with
  these URLs on the next run, and a single failed connection during the lookup is
  retried once before it is reported.

## 1.4.0

- AlmaLinux / RHEL 10 is supported: the LiteSpeed repository does publish el10
  builds, and from release 10 the packages are signed with the key LiteSpeed
  rotated in 2025, which the setup now picks by major release the same way the
  official repository bootstrap does.
- The Red Hat repository recipe writes both sets LiteSpeed publishes - the
  release repository and the update repository that carries the rebuilds - and it
  rewrites its own file when an older version of this extension left a partial
  copy behind.
- The package manager metadata is refreshed and the package is looked up before
  anything is installed, so a stale or empty cache is no longer reported as
  "no such package". When the lookup fails, the message says which repository was
  asked; when a dependency is missing, it names the dependency instead of
  swallowing the package manager's output.
- The signing key is always fetched from the recipe URL before it is used,
  because the file name is fixed while its content is not.
- Fixed: the first-run page could sit on "the setup is running" with a single log
  line and never move. The state file was written after the worker started, which
  erased the progress the worker had already recorded and its process id with it.
  The state now goes down first, the worker keeps its process id in a file of its
  own, and a page that finds no live worker reports an interrupted setup with the
  log instead of promising progress for forty minutes. A PHP error inside the
  worker is recorded as a failure too, and the running page carries a refresh link
  for a browser that never runs the auto-refresh script.
- When the package manager reports an unresolvable dependency, the page names the
  missing requirement instead of swallowing its output. (Covered in 1.4.1: the one
  dependency this actually needs is EPEL's `gd`.)

## 1.3.9

- The Web engine page no longer carries a domain table. The numbers that matter
  (mapped domains, PHP execution mode, automatic sync, last sync) stay in the
  status card; the per-domain certificate and health details are what the
  Virtual hosts page and the logs already show.
- The update answer is one compact line inside the service status card instead of
  a separate card below it, and the quick links sit side by side instead of
  stacking.
- The first-run page finishes with a single action - "Open the dashboard". The
  "Web engine" button next to it was redundant.
- Fixed: the PHP pool this extension starts for Plesk's own service hostnames
  (webmail) never came up. Plesk's php-fpm rejects a `syslog` entry, so the pool
  died during initialization, and its socket sat in a directory the OpenLiteSpeed
  worker (`nobody:psaserv`) is not allowed to enter. The pool files now live in
  their own directory created 0710 root:psaserv, exactly like Plesk's
  `/var/www/vhosts/system/<domain>`, so Apache can leave the request path.
- Removing an extension copy of stale pool files left over from the old location
  is done by the install script.

## 1.3.8

- Simplified the Dashboard: it no longer repeats the OpenLiteSpeed version,
  process id, worker count, control method, installation directory,
  configuration format or virtual host count, no longer spells out the web admin
  console's port, TLS, binding, reachability and user list (the console button
  in the page header already opens it), and no longer shows the operating system
  or the nginx/Apache service names. Quick links now carry icons.
- Simplified the Web Engine page: the public listener table and the summary line
  under it (PHP backend, public IP addresses, worker group) are gone, the front
  status line no longer prints a PID, and the domain table is headed simply
  "Domains".
- The interface no longer names the PHP backend: the execution mode reads
  "Direct on OpenLiteSpeed" or "Apache backend", and the per-domain badge reads
  "Direct".
- Fixed: reinstalling the extension never brought the first-run page back. Both
  the stored "already been through it" record and the mere presence of the front
  block silenced it permanently. Installing now clears that record, and on a
  server that already runs on OpenLiteSpeed the page shows the finished state
  once and then closes its own gate, so the next click lands on the panel
  instead of looping.
- Fixed: the configuration editor's save confirmation stayed in English in the
  Turkish panel - its catalog key was written in single quotes, so the `\n`
  escapes in the source never became the newlines the catalog stores.

## 1.3.7

- Fixed: with "PHP execution: direct" a PHP site returned **500 — Failed opening
  required 'wp-config.php': Permission denied**. The request never reached
  Plesk's php-fpm pool, for two separate reasons:
  - The generated `type fcgi` extprocessor let OpenLiteSpeed take ownership of
    the pool. It then tried to lock a pid file beside Plesk's socket
    (`php-fpm.sock.pid: Permission denied` as `nobody`) and dropped the handler.
    The extprocessor now declares `autoStart 0` and no `path`/`instances`, which
    is how OpenLiteSpeed expresses "this backend is started by somebody else,
    only connect to it". (`path` is only required when the server starts the
    app, so `lshttpd -t` no longer reports `missing <path>`.)
  - The `.php` association was written into the `virtualHost` registration
    inside `httpd_config.conf`, where the parser accepts it but never uses it.
    It belongs in the virtual host's own `vhconf.conf`, as
    `scripthandler { add fcgi:<app> php }`, and is now generated there - which is
    also the only place it can override the stock `lsphp` handler.
    The plain-text form is the one the server writes itself; the `addsuffix`
    node the web admin console shows has no plain-text syntax and is rejected
    (`Not support [addsuffix php]`).
  PHP is now served by the pool Plesk runs, so the answer comes back as
  `Server: LiteSpeed` with the PHP version selected for the subscription, and
  Apache stays stopped.
- Fixed: "Graceful Reload" failed with `Usage: lswsctrl {start|stop|restart|…}`.
  lswsctrl has no `graceful` verb; it is `reload`. The same mapping is applied to
  `systemctl` (whose `lsws.service` defines `ExecReload`).
- Fixed: the reported PID, uptime and worker count could name a process that was
  not OpenLiteSpeed. LiteSpeed rewrites its process titles
  (`openlitespeed (lshttpd - main)`) and ships no pid file at the usual paths, so
  the search by binary path found nothing and the fallback matched unrelated
  processes; the master is now found by its own process title.
- Verified on a live Plesk box: single click into direct mode, the reverse switch
  back to nginx + Apache and the single click again all completed with no
  downtime, no generated leftovers and no `lshttpd -t` errors; HTTP 301 to HTTPS,
  WordPress front page and `wp-login.php` answered 200, a missing page answered
  404, and a graceful restart kept every site serving.

## 1.3.1

- Fixed: "PHP execution: direct" left every domain on the Apache backend
  (`PHP direct domains: 0`), so Apache stayed running and the request still made
  the hop the mode was meant to remove. A php-fpm pool socket is a unix socket,
  not a regular file, and `is_file()` returns false for it, so
  `plesk_php_socket()` never found Plesk's `/var/www/vhosts/system/<domain>/php-fpm.sock`
  and no domain ever qualified as direct-capable. Pool sockets are now detected
  with `file_exists()`, which sees sockets too. After this fix a domain with a
  live Plesk pool and a document root goes direct, Apache is stopped and
  disabled when nothing needs it, and PHP is answered with
  `Server: LiteSpeed` and no Apache hop.
- Re-syncing domains, or running the welcome page single click again, is enough
  to pick the pools up; no configuration from earlier versions has to be undone
  by hand.

## 1.3.0

- First run now opens a welcome page with a single button. It checks the server,
  installs OpenLiteSpeed with the distribution package manager when it is
  missing (LiteSpeed's official repository for RHEL 8/9/10 and Debian/Ubuntu
  releases that publish a 1.8+ build), maps every Plesk domain, moves 80/443 to
  OpenLiteSpeed and health-checks the result - all in a detached root worker so
  a package install cannot time out in the panel. The page hides itself once the
  administrator has been through it, appears again after the extension is
  removed and reinstalled, and can be shown on purpose from the Settings page.
- OpenLiteSpeed can now be the whole web front: a new "PHP execution" choice on
  the Web Engine page runs PHP directly in the php-fpm pool Plesk already starts
  for each domain (`type fcgi` extprocessor on the domain's
  `/var/www/vhosts/system/<domain>/php-fpm.sock`) and serves the domain's
  docroot itself. The Apache hop is gone, which is the point of moving to
  OpenLiteSpeed. The Plesk PHP version stays authoritative - no `lsphp` packages
  are installed and no Plesk configuration is edited.
- Apache is stopped and disabled whenever no domain needs it any more, and the
  OpenLiteSpeed worker group is switched to the Plesk web group (`psaserv`) so
  it can read the docroots and connect to the sockets. The original group is
  recorded and restored, and Apache is re-enabled and started again on
  "Switch to Plesk", on a re-sync that needs it, and on uninstall.
- Domains that Plesk forces to HTTPS keep that behaviour without Apache: the
  front generates a small redirect virtual host with a `RewriteRule` 301 to the
  https listener.
- OpenLiteSpeed rewrites `httpd_config.conf` in its own block order when the
  server restarts, which can orphan the extension's begin marker. The generated
  stanzas are therefore recognised and cleaned by their own names
  (`PleskHttpBackend`, `PleskTls*`, `pl-*` vhosts, `PleskPlain-*`/`PleskSecure-*`
  listeners), and switching back to Plesk now also removes the generated `pl-*`
  vhost directories from disk instead of leaving them behind.
- Per-domain PHP mode, the Apache verdict and the worker group are all shown on
  the Web Engine page (new PHP column in the domain table, PHP execution row in
  the status grid, listener footer).
- Results are presented as panel-style toasts instead of inline message blocks,
  and a Back button returns to the Plesk admin pages, so the module no longer
  feels like a dead end.
- Interface cleanup: the verbose `BUILD built: ...` text is stripped from the
  reported version, the Uptime badge is gone, the subtitle reads "OpenLiteSpeed
  for Plesk", the redundant firewall/service-name hints are removed, select
  controls get proper padding instead of clipped text and the meta grids are
  restyled.
- Fixed: "Yapılandırmayı eşitle" returned
  `Zend_Controller_Action_Exception — Action "enginesync" does not exist`. Zend
  lowercases the action token, so the controller actions and the view links now
  all use the lowercase names.

## 1.2.0

- Turkish and English interface. The module follows the panel language
  automatically; a header language pill and an "Interface language" setting
  override it for this module only. All screen text and all root-helper error
  messages are translated, including messages that carry a dynamic tail
  (paths, PIDs, `lshttpd -t` output).
- Web Admin Console access: the dashboard and the header show the detected
  console listener (port, TLS, bind, reachability, existing usernames only) and
  open it in a new tab. Console credentials can be created from the Settings
  page - bcrypt hashed exactly like `admpass.sh`, written only to the console
  credentials file, never to the Plesk database. A manual console URL override
  is available for load-balanced or firewalled setups.
- OpenLiteSpeed logo and a modernised interface: redrawn layout with status
  badges, icon action buttons, a service toggle, card-based dashboard, and the
  author/version footer.
- Fixed: `<select>` controls were unreadable when the panel ran in dark mode.
  Form controls now declare their own colours and `color-scheme`.
- Fixed: "A valid --vhost name is required for vhost logs." The vhost log views
  now default to a real virtual host, resolve log paths across the layouts
  OpenLiteSpeed uses, and the UI shows an explanatory message instead of an
  error when the installation genuinely has no vhost.
- Uninstall now reverts: removing the extension runs the same switch back to
  nginx + Apache (cron timer removed, front block stripped, generated vhosts
  deleted, nginx re-enabled and started, OpenLiteSpeed released from 80/443)
  with a timestamped backup and a health check. Reinstalling afterwards stays a
  deliberate choice.
- Cross-distribution support: Apache and nginx unit names are detected instead
  of assumed (`httpd` on RPM families, `apache2` on Debian families), the
  operating system family is reported on the dashboard, service control falls
  back where systemd is absent, and HTTP probing falls back from `curl` to a
  plain socket request.
- System service registration moved to `hooks/SystemServices.php`; Plesk loads
  hooks by file name, so the previous `hooks/Services.php` never registered the
  switch.
- Added a second entry point under Tools & Settings -> Server Management, with
  an explicit menu order for the admin navigation entry.

## 1.1.0

- New "Web Engine" tab: one-click switch of the public web front between
  nginx + Apache (Plesk stock) and OpenLiteSpeed, in both directions.
- OpenLiteSpeed front generation reads Plesk's own nginx configuration:
  per-domain SNI certificates, all public IPs, port 80/443 listeners and an
  Apache backend proxy, so existing and newly added domains keep working.
- Every switch is protected by `lshttpd -t` validation, a timestamped backup,
  a live HTTP health check of all domains and automatic rollback on failure.
- Domains that were already unreachable before the switch are detected first
  and excluded from the rollback decision.
- Each HTTPS domain gets its own Apache TLS upstream, so pooled backend
  connections stay single-host and mod_ssl never answers HTTP 421
  (the equivalent of nginx `proxy_ssl_name $host`).
- Automatic front sync: a `/etc/cron.d` timer compares a fingerprint of Plesk's
  domain/certificate/backend facts every 2 minutes and rebuilds the front only
  when something actually changed. New, renamed or removed domains and renewed
  certificates are picked up without touching the panel; an idle server is never
  reloaded. The timer is installed on the switch to OpenLiteSpeed and removed on
  the way back and on uninstall.
- Re-sync button rebuilds the front mapping on demand after Plesk domain changes;
  applying a rebuild that changes no listener port uses a graceful reload, so
  live connections survive. Only an IP change forces a full stop/start.
- Generated vhost directories left behind by removed domains are pruned on every
  rebuild; nginx is stopped + disabled while OpenLiteSpeed fronts traffic and is
  re-enabled and started again on the way back.
- Configuration editor now supports the OpenLiteSpeed 1.8+ plain-text format
  (httpd_config.conf / vhconf.conf) as well as the legacy XML format, and
  validates with error-line detection instead of exit code.
- OLS admin listener is moved off port 7080 (Plesk Apache backend) when the
  front is installed.

## 1.0.0

- Initial release by YasinKarakurt - Yasin Karakurt.
- Dashboard: OpenLiteSpeed status, version, uptime, PID, workers, listeners.
- Start / Stop / Restart / Graceful Reload / Test Configuration actions.
- Service switch registered in Plesk "Services Management" (pm_Hook_SystemServices).
- Menu entry "OpenLiteSpeed" in the admin Server Management section.
- Configuration editor for httpd_config.xml and vhost configs with backup,
  lshttpd -t validation and automatic rollback.
- Virtual host list with docroot/TLS info and per-vhost log shortcuts.
- Log viewer for server/vhost/admin error and access logs.
- Settings: custom OpenLiteSpeed installation prefix override.
